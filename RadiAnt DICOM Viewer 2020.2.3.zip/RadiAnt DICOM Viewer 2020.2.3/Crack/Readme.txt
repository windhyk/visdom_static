replace the correct executable according with bits version installed
